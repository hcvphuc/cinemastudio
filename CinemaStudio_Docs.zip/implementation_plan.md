# Fix API Key Flow — Root Cause & Plan

## Problem

"Failed to fetch" / "Invalid API key" errors across Script Analysis and all AI hooks.

## Root Cause Analysis

```mermaid
flowchart TD
    A["App.tsx line 110\nuserApiKey = localStorage.getItem('geminiApiKey')"] -->|"Always reads 'geminiApiKey'"| B["Passed as prop to 15+ hooks"]
    B --> C["useScriptAnalysis(userApiKey)"]
    B --> D["useScriptGeneration(userApiKey)"]
    B --> E["useCharacterLogic(userApiKey)"]
    B --> F["... 12 more hooks"]
    C --> G["getAIProvider(userApiKey)"]
    G -->|"Key = 'AIza...' → OK"| H["✅ GeminiProvider"]
    G -->|"Key = 'vai-...' → OK"| I["✅ VertexKeyProvider"]
    G -->|"Key = '' (empty!) → FAIL"| J["❌ No API key error"]

    style A fill:#ff6b6b,color:#fff
    style J fill:#ff6b6b,color:#fff
```

> [!CAUTION]
> **The core bug**: `App.tsx` reads `localStorage.getItem('geminiApiKey')` at line 110.
> When user configures Vertex Key in Settings, the key is stored under `vertexKeyApiKey` — but `App.tsx` never reads that.
> Result: `userApiKey = ''` → all hooks receive empty key → all AI calls fail.

**Even when user enters Gemini key in Settings provider panel**, it may be stored under `geminiApiKey` via `setProviderConfig()` but `App.tsx` reads from `localStorage.getItem('geminiApiKey')` directly. These are the SAME key in localStorage, but there are TWO separate systems for managing it:

| System | How key is stored | How key is read |
|--------|------------------|-----------------|
| **Legacy** (App.tsx) | `localStorage.setItem('geminiApiKey', key)` | `localStorage.getItem('geminiApiKey')` |
| **Provider** (aiProvider.ts) | `setProviderConfig({ geminiApiKey, vertexKeyApiKey })` | `getProviderConfig()` → `getActiveApiKey()` |

These two systems conflict. The old `userApiKey` prop flows through 15+ hooks as a **legacy** mechanism, while `getAIProvider()` has its own key detection.

## Proposed Changes

### Strategy: Centralize on `getActiveApiKey()`

Remove the legacy `userApiKey` prop chain. Instead, hooks call `getAIProvider()` (no override) which internally reads the correct key from `getProviderConfig()`.

---

### Core Provider Layer

#### [MODIFY] [aiProvider.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/utils/aiProvider.ts)

- Keep `getAIProvider()` signature, but when called **without** override, it reads from `getProviderConfig()` and auto-selects the right provider + key
- This already works correctly — no changes needed here

---

### App Entry Point  

#### [MODIFY] [App.tsx](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/App.tsx)

**Line 110**: Change `userApiKey` to read from `getActiveApiKey()` instead of hardcoded `'geminiApiKey'`:

```diff
- const [userApiKey, setUserApiKey] = useState(() => localStorage.getItem('geminiApiKey') || '');
+ const [userApiKey, setUserApiKey] = useState(() => getActiveApiKey());
```

**Line 1065-1066**: When setting key from Settings, also update provider config:
```diff
  setApiKey={(key: string) => {
    setUserApiKey(key);
-   localStorage.setItem('geminiApiKey', key);
+   localStorage.setItem('geminiApiKey', key);
+   setProviderConfig({ geminiApiKey: key });
  }}
```

> [!IMPORTANT]
> This is the **minimal, safest fix** that preserves the existing `userApiKey` prop chain while making it read the correct active key. All 15+ hooks continue receiving the key as a prop — no need to refactor them all.

---

### Script Analysis Hook

#### [MODIFY] [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts)

Already migrated to `getAIProvider(userApiKey)` — the fix in `App.tsx` will provide the correct key.

---

## Verification Plan

### Automated Tests
```bash
# Test Gemini Direct key
node -e "const { GoogleGenAI } = require('@google/genai'); \
  const ai = new GoogleGenAI({ apiKey: 'AIzaSyANnQx4LWRiXFgix2VwLPl17Pkip_nG1H4' }); \
  ai.models.generateContent({ model: 'gemini-2.5-flash', contents: [{role:'user',parts:[{text:'Say ok'}]}] }) \
  .then(r => console.log('✅', r.text)).catch(e => console.log('❌', e.message))"
```

### Manual Verification
1. Set provider to **Gemini Direct** with key `AIza...` → Analyze Script → should work
2. Set provider to **Vertex Key** with key `vai-...` → Analyze Script → should show clear "server down" error (vertex-key.com is 502), NOT "invalid key"
3. Switch between providers → each uses the correct key

# Sơ đồ Logic: Phân tích Kịch bản

## Tổng quan

Khi user nhập brief (kịch bản voiceover) vào **ManualScriptModal** và bấm **"Phân tích"**, hệ thống chạy qua **6 giai đoạn** với 2 lần gọi Gemini AI.

```mermaid
flowchart TD
    A["🎬 User nhập Brief\n+ chọn Style/Director/Model"] --> B{"Bấm Phân tích"}
    B --> C["Stage 1: PREPARING\nKiểm tra API key, tính WPM"]
    C --> D["Stage 2: DIALOGUE DETECTION\nRegex detect lời thoại"]
    D --> E["Stage 3: CHAPTER DETECTION\nRegex detect headers/chapters"]
    E --> F["Stage 4: CLUSTERING\n🤖 AI Call #1 - Visual Director"]
    F --> G["Stage 5: THINKING → CONNECTING\n🤖 AI Call #2 - JSON Generation"]
    G --> H["Stage 6: POST-PROCESSING\nEnforce scene count + fix chapters"]
    H --> I["✅ Hiển thị kết quả\nChapters, Characters, Scenes"]
    I --> J{"User bấm Import?"}
    J -->|Yes| K["generateSceneMap()\nTạo Scenes + Groups + Characters"]
    K --> L["📋 Project State Updated"]
```

## Chi tiết từng giai đoạn

### Stage 1: Preparing
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L196-204)

| Input | Output |
|-------|--------|
| `scriptText`, `readingSpeed` | `wordCount`, `estimatedDuration` |
| `modelSelector` (e.g. `gemini-2.5-flash\|none`) | `modelName`, `thinkingBudget` |

- Tính WPM: slow=120, medium=150, fast=180
- Tính tổng thời lượng video ước tính

### Stage 2: Dialogue Detection (Regex)
> File: [preProcessDialogue()](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L92-143)

```
Input:  "He looked at her. 'I can't do this,' he whispered."
Output: dialogueHints = [{ speaker: "he", text: "I can't do this" }]
```

- Regex detect các pattern: `"..."`, `'...'`, `— ...`, `Character: "..."`
- Tạo `dialogueHints` cho AI dùng ở Step 2

### Stage 3: Chapter/Header Detection (Regex)
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L218-330)

```mermaid
flowchart LR
    A["Script lines"] --> B{"Có [bracket] headers?"}
    B -->|"[PART A: HOOK]"| C["Dùng bracket chapters\nFallback patterns TẮT"]
    B -->|Không| D["Fallback patterns:\n- Place, Month Year\n- PART X: Title\n- Time jump phrases\n- The [Word]"]
    C --> E["chapterMarkers[]"]
    D --> E
```

**Priority**: `[Bracket format]` > PART headers > Location/Date patterns

### Stage 4: Visual Clustering (🤖 AI Call #1)
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L409-555)

| Config | Value |
|--------|-------|
| Model | Luôn `gemini-2.5-flash` (nhanh) |
| Mục đích | Chuyển script → danh sách "visual shots" (text, chưa JSON) |

**System Prompt** bao gồm:
- **Beat Detection Rules**: Number+Action, Dramatic verbs, Establishing vs Action
- **Creative Intensity**: `[C1]` Literal, `[C2]` Suggestive, `[C3]` Metaphoric
- **Parentheses Protocol**: Text trong `(...)` = visual direction, không đọc VO
- **BBC 5-Shot Rule**: CU Hands, CU Face, Wide, OTS, Creative Angle

**Output**: `visualPlan` (text dạng "Shot 1: ..., Shot 2: ...")

### Stage 5: JSON Generation (🤖 AI Call #2)
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L558-725)

| Config | Value |
|--------|-------|
| Model | User-selected (e.g. `gemini-2.5-flash`, `gemini-3-pro-preview`) |
| Temperature | 0.3 (deterministic) |
| Response | `application/json` |
| Max tokens | 65,536 |
| Thinking | Optional budget (high=24K, medium=8K, low=2K) |

**Input**: Original script + Visual Plan (từ Step 4) + Context injections

**Context Injections** (nếu có):
1. 🌍 **Story Context** (global world setting)
2. 🎨 **Character Style** (Mannequin / Cinematic / Anime...)
3. 🎬 **Director Vision** (style instructions)
4. 📝 **Research Notes** (Director + DOP notes)
5. 👥 **Existing Characters** (avoid duplicates)
6. 💬 **Dialogue Hints** (from Stage 2)
7. 📍 **Chapter Hints** (from Stage 3, HARD LOCKED)

**Output JSON**:
```json
{
  "globalContext": "World summary...",
  "locations": [{ "id": "loc_casino", "name": "Casino", "conceptPrompt": "..." }],
  "chapters": [{ "id": "ch_1", "title": "...", "locationAnchor": "..." }],
  "characters": [{ "name": "John", "suggestedDescription": "...", "outfitByChapter": {} }],
  "scenes": [{
    "voiceOverText": "...",
    "dialogueText": null,
    "visualPrompt": "WIDE SHOT. ...",
    "chapterId": "ch_1",
    "characterNames": ["John"],
    "needsExpansion": false,
    "expansionScenes": []
  }]
}
```

### Stage 6: Post-Processing
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L727-970)

```mermaid
flowchart TD
    A["JSON from AI"] --> B["Parse + Calculate durations"]
    B --> C{"scenes > target × 1.1?"}
    C -->|Yes| D["Merge shortest scenes\nuntil within range"]
    C -->|No| E["OK"]
    D --> E
    E --> F{"chapterMarkers exist?"}
    F -->|Yes| G["Override chapterId per scene\nbased on text position in script"]
    F -->|No| H["Keep AI assignments"]
    G --> I["Validate dialogue separation"]
    H --> I
    I --> J["✅ Final ScriptAnalysisResult"]
```

**3 post-processing steps**:
1. **Scene Count Enforcement**: Nếu AI tạo quá nhiều scenes → merge shortest adjacent scenes
2. **Chapter Override**: Tìm vị trí text trong script gốc → gán đúng `chapterId` (fix lỗi AI gán sai chapter)
3. **Dialogue Validation**: Kiểm tra VO/Dialogue tách đúng chưa

### Import: generateSceneMap()
> File: [useScriptAnalysis.ts](file:///c:/Users/Administrator/.gemini/antigravity/playground/ionic-asteroid/hooks/useScriptAnalysis.ts#L1044-1220)

Khi user bấm **Import**, hệ thống:
1. Tạo `SceneGroup[]` từ chapters (mỗi chapter = 1 group)
2. Tạo `Scene[]` với visual prompt, VO text, character assignments
3. Tạo `Character[]` mới (nếu phát hiện nhân vật mới)
4. Map characters → scenes (ai nhân vật nào xuất hiện ở scene nào)
5. Xử lý B-Roll expansion scenes
6. Update `ProjectState`

## Data Flow Summary

```
User Brief → Regex (Dialogue + Chapters) → AI #1 (Visual Shots) → AI #2 (JSON) → Post-process → UI Preview → Import → Project
```

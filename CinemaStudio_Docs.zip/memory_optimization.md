# 🧠 Memory Optimization - Browser Crash Fix

## Vấn đề
Browser crash (dead) sau khi tạo ~15 hình do tràn RAM. Đồng thời save ZIP rồi load lại bị lỗi.

## Root Cause Analysis

### Nguyên nhân chính: Base64 Image Strings trong JS Heap

| Yếu tố | RAM tiêu thụ |
|---------|-------------|
| 1 ảnh base64 (1024x1024) | ~3-5 MB |
| 15 ảnh trong React state | ~45-75 MB |
| Undo history (50 entries × tất cả ảnh) | **~500-1400 MB** |
| ImageCache (100 entries) | ~300-500 MB |
| **Tổng** | **~1-2 GB → CRASH** |

### Chi tiết
1. **`callGeminiAPI`** trả về `data:image/png;base64,...` (3-5MB string mỗi ảnh)
2. **`updateStateAndRecord`** lưu toàn bộ state (kèm ảnh) vào `history.past`
3. **Post-import** gọi `updateStateAndRecord` 2-3 lần/character → 30+ history entries
4. **ImageCache** giữ 100 entries base64 data (không giới hạn)

## Giải pháp (5 tầng)

### 1. ⭐ Base64 → Blob URL (Core Fix)
**Files:** `geminiUtils.ts`, `useImageGeneration.ts`

```
Trước: return `data:image/png;base64,${base64Data}` // ~3-5 MB string
Sau:   return URL.createObjectURL(blob)              // ~50 bytes string
```

- Blob URL là pointer tới binary data trong browser blob storage (NGOÀI JS heap)
- Ảnh vẫn hiển thị bình thường qua `<img src="blob:..."/>`
- **Tiết kiệm ~99% RAM** cho mỗi ảnh trong state

### 2. Batch Gen không lưu Undo History
**Files:** `useStateManager.ts`, `usePostImportGeneration.ts`, `App.tsx`

- Thêm `updateStateWithoutHistory()` — update state nhưng KHÔNG push vào `history.past`
- Post-import generation sử dụng hàm này thay vì `updateStateAndRecord`
- **30+ history entries × state full ảnh = 0 MB overhead**

### 3. Giảm Undo History
**File:** `useStateManager.ts`

- Max entries: `50 → 20`
- Mỗi entry vẫn nhẹ hơn nhờ blob URLs

### 4. Giảm ImageCache
**File:** `geminiUtils.ts`

- Max size: `100 → 20`
- TTL: `30 min → 10 min`

### 5. Fix ZIP Save/Load
**File:** `zipUtils.ts`

- `prepareImageForZip`: Thêm xử lý `blob:` URLs
- `restoreImage`: Trả về Blob URL thay vì base64 data URI
- `safeGetImageData`: Thêm xử lý `blob:` URLs cho API calls

## Kết quả ước tính

| Metric | Trước | Sau |
|--------|-------|-----|
| RAM/ảnh trong state | 3-5 MB | ~50 bytes |
| 100 ảnh trong state | 300-500 MB | ~5 KB |
| Undo history (20 entries) | Hàng GB | ~1 KB pointer |
| ImageCache | 300-500 MB | ~60 MB (20 entries) |
| **Post-import 15 chars** | **~1.4 GB → CRASH** | **~1 MB → OK** |
